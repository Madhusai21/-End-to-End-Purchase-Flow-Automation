from time import sleep

from selenium import webdriver

from PythonProject.POM.Pages.PlaceorderPOM import PlaceOrder
from PythonProject.POM.Pages.SigupPagePOM import Signup
from PythonProject.POM.Pages.LoginPagePOM import Login
from PythonProject.POM.Pages.ProductPOM import Product
from PythonProject.POM.Pages.AddcartPOM import Cart
import pytest
#-----------
@pytest.mark.usefixtures("setup")
def test_signup(setup):
    driver=setup
    # m=Signup(driver)
    # m.sign_button_click()
    # m.sign_up_page("kumar","kumar@123")
    # m.driver.switch_to.alert.accept()
    # m.alert_oks()
    # sleep(5)
#---------
    m=Login(driver)
    m.login_button()
    m.login_page("Madhusai","Madhu@21")
    sleep(5)
#----------
    m=Product(driver)
    m.product_info()
    sleep(5)
#----------
    m=Cart(driver)
    m.cart_info()
    m.cart_alert()
    # m.driver.switch_to.alert.accept()
    m.cart_add_ok()
    sleep(5)

    m=PlaceOrder(driver)
    m.order_info("madhusai","india","Bangalore",9876573544001,12,2002)
    sleep(4)
    m.home_clicks()
    sleep(5)



