from selenium import webdriver
import pytest
from time import sleep
@pytest.fixture(scope="function")
def setup():
    driver=webdriver.Chrome()
    driver.get('https://www.demoblaze.com/index.html')
    driver.maximize_window()
    driver.implicitly_wait(10)
    yield driver
    sleep(5)
    driver.quit()