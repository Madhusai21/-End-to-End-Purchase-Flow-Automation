class PlaceOrder:
    def __init__(self,driver):
        self.driver=driver
        self.name_felid=("id","name")
        self.country_felid=("id","country")
        self.city_felid=("id","city")
        self.card_felid=("id","card")
        self.month_felid=("id","month")
        self.year_felid=("id","year")
        self.click1=("xpath","//*[@id='orderModal']/div/div/div[3]/button[2]")
        self.home_page=("xpath","/html/body/div[10]/div[7]/div/button")

    def order_info(self,name,country,city,card,month,year):
        self.driver.find_element(*self.name_felid).send_keys(name)
        self.driver.find_element(*self.country_felid).send_keys(country)
        self.driver.find_element(*self.city_felid).send_keys(city)
        self.driver.find_element(*self.card_felid).send_keys(card)
        self.driver.find_element(*self.month_felid).send_keys(month)
        self.driver.find_element(*self.year_felid).send_keys(year)
        self.driver.find_element(*self.click1).click()
    def home_clicks(self):
        self.driver.find_element(*self.home_page).click()

