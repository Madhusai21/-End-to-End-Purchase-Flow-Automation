from selenium import webdriver
class Product:
    def __init__(self,driver):
        self.driver=driver
        self.product_name=("link text","Monitors")
        self.product_name1=("link text","Laptops")
        self.product_name2=("link text","Sony vaio i7")

    def enter_product_name(self):
        self.driver.find_element(*self.product_name).click()

    def enter_product_name1(self):
        self.driver.find_element(*self.product_name1).click()

    def enter_product_name2(self):
        self.driver.find_element(*self.product_name2).click()


    def product_info(self):
        self.enter_product_name()
        self.enter_product_name1()
        self.enter_product_name2()


