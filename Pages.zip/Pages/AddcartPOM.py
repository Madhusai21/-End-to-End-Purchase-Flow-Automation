from selenium import  webdriver

class Cart:
    def __init__(self,driver):
        self.driver=driver
        self.add_cart=("link text","Add to cart")
        self.alert_cart=("id","cartur")
        self.add_btn=("xpath","/html/body/div[6]/div/div[2]/button")

    def item_add(self):
        self.driver.find_element(*self.add_cart).click()
    def item_alert(self):
        self.driver.find_element(*self.alert_cart).click()
    def item_add_ok(self):
        self.driver.find_element(*self.add_btn).click()

    def cart_info(self):
        self.item_add()
    def cart_alert(self):
        self.item_alert()
    def cart_add_ok(self):
        self.item_add_ok()





