class Login:
    def __init__(self,driver):
        self.driver=driver
        self.click_Login = ("id", "login2")
        self.user_name = ("id", "loginusername")
        self.pass_word = ("id", "loginpassword")
        self.logins = ("xpath", "//button[text()='Log in']")
    def login_btn(self):
        self.driver.find_element(*self.click_Login).click()

    def enter_username(self, username):
        self.driver.find_element(*self.user_name).send_keys(username)

    def enter_password(self, password):
        self.driver.find_element(*self.pass_word).send_keys(password)

    def click_login(self):
        self.driver.find_element(*self.logins).click()
#--------------------
    def login_button(self):
        self.login_btn()
#-------------------------
    def login_page(self,username,password):
        self.enter_username(username)
        self.enter_password(password)
        self.click_login()


