class Signup:
    def __init__(self,driver):
        self.driver=driver
        self.click_signup=("id","signin2")
        self.user_name=("id","sign-username")
        self.pass_word=("id","sign-password")
        self.signup_btn=("xpath","//button[text()='Sign up']")
        self.alert_ok=("xpath","/html/body/div[2]/div/div/div[3]/button[1]")
    def sign_button(self):
        self.driver.find_element(*self.click_signup).click()
    def enter_username(self,username):
        self.driver.find_element(*self.user_name).send_keys(username)
    def enter_password(self,password):
        self.driver.find_element(*self.pass_word).send_keys(password)
    def signup(self):
        self.driver.find_element(*self.signup_btn).click()
    def alerts(self):
        self.driver.find_element(*self.alert_ok).click()

#-------
    def sign_button_click(self):
        self.sign_button()
#----------
    def sign_up_page(self,username,password):
        self.enter_username(username)
        self.enter_password(password)
        self.signup()
    def alert_oks(self):
        self.alerts()




